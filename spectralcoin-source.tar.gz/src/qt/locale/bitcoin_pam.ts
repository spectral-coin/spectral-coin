<TS language="pam" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>I-right click ban alilan ing address o libel</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Maglalang kang bayung address</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Bayu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Kopyan me ing salukuyan at makipiling address keng system clipboard</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopyan</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>I&amp;sara</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Ilako ya ing kasalungsungan makapiling address keng listahan</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Magpalub kang address o label para pantunan</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Ilako</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Dialogo ning Passphrase</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Mamalub kang passphrase</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Panibayung passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Pasibayuan ya ing bayung passphrase</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>I-sign ing &amp;mensayi</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Mag-sychronize ne king network...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Overview</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Ipakit ing kabuuang lawe ning wallet</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaksion</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Lawan ing kasalesayan ning transaksion</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>L&amp;umwal</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Tuknangan ing aplikasyon</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Tungkul &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Magpakit impormasion tungkul king Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Pipamilian...</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>I-&amp;Encrypt in Wallet...</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>I-&amp;Backup ing Wallet...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Alilan ing Passphrase...</translation>
    </message>
    <message>
        <source>Send coins to a spectralcoin address</source>
        <translation>Magpadalang barya king spectralcoin address</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>I-backup ing wallet king aliwang lugal</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Alilan ya ing passphrase a gagamitan para king wallet encryption</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>I-&amp;Debug ing awang</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Ibuklat ing debugging at diagnostic console</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Beripikan ing message...</translation>
    </message>
    <message>
        <source>spectralcoin</source>
        <translation>spectralcoin</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Ipalto / Isalikut</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Ipalto o isalikut ing pun a awang</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Pamag-ayus</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Saup</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Gamit para king Tabs</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>Pipamilian command-line</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Ing tatauling block a metanggap,  me-generate ya %1 ing milabas</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Ing transaksion kaibat na nini ali yapa magsilbing ipakit.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Kapabaluan</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>&amp;Impormasion</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Makatuki ya king aldo</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Awang</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Catching up...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Mipadalang transaksion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Paparatang a transaksion</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Maka-&lt;b&gt;encrypt&lt;/b&gt; ya ing wallet at kasalukuyan yang maka-&lt;b&gt;unlocked&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Maka-&lt;b&gt;encrypt&lt;/b&gt; ya ing wallet at kasalukuyan yang maka-&lt;b&gt;locked&lt;/b&gt;</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Alaga:</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Alaga</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Kaaldauan</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Me-kumpirma</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Alilan ing Address</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Label</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Address</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>bersion</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Pipamilian command-line</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Malaus ka</translation>
    </message>
    <message>
        <source>spectralcoin</source>
        <translation>spectralcoin</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Tatauling oras na ning block</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Pipamilian</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Pun</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Network</translation>
    </message>
    <message>
        <source>Automatically open the spectralcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Ibuklat yang antimanu ing spectralcoin client port king router. Gagana yamu ini istung ing router mu susuporta yang UPnP at magsilbi ya.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Mapa ng ning port gamit ing &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port na ning proxy(e.g. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Awang</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Ipakit mu ing tray icon kaibat meng pelatian ing awang.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Latian ya ing tray kesa king taskbar</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>P&amp;alatian istung isara</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;Ipalto</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>Amanu na ning user interface:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>Ing &amp;Unit a ipakit king alaga ning:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Pilinan ing default subdivision unit a ipalto o ipakit king interface at istung magpadala kang barya.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>I-&amp;Cancel</translation>
    </message>
    <message>
        <source>default</source>
        <translation>default</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Ing milageng proxy address eya katanggap-tanggap.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the spectralcoin network after a connection is established, but this process has not completed yet.</source>
        <translation>Ing makaltong impormasion mapalyaring luma ne. Ing kekang wallet otomatiku yang mag-synchronize keng spectralcoin network istung mekakonekta ne king network, oneng ing prosesung ini ali ya pa kumpletu.</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Ing kekang kasalungsungan balanse a malyari mung gastusan</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Ing kabuuan dareng transaksion a kasalungsungan ali pa me-kumpirma, at kasalungsungan ali pa mebilang kareng kekang balanseng malyari mung gastusan</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Immature:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>Reng me-minang balanse a epa meg-matured</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Kabuuan:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Ing kekang kasalungsungan kabuuang balanse</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Alaga</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>e miya balu</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Bersion ning Cliente</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Impormasion</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>I-Debug ing awang</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Oras ning umpisa</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Network</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Bilang dareng koneksion</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Block chain</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Kasalungsungan bilang dareng blocks</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Tatauling oras na ning block</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Ibuklat</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Console</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Kabuuan:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debug log file</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>I-Clear ing console</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Kopyan ing address</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Magpadalang Barya</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Kulang a pondo</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Alaga:</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Bayad king Transaksion:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Misanang magpadala kareng alialiuang tumanggap</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Maglage &amp;Tumanggap</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>I-Clear &amp;Eganagana</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Balanse:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Kumpirman ing aksion king pamagpadala</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>Ipadala</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Bayad king Transaksion</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>A&amp;laga:</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Ibayad &amp;kang:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Label:</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Idikit ing address menibat king clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Mensayi:</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Ibayad kang:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Pirma - Pirman / I-beripika ing mensayi</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Pirman ing Mensayi</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Idikit ing address menibat king clipboard</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Ipalub ing mensayi a buri mung pirman keni</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Pirma</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Kopyan ing kasalungsungan pirma king system clipboard</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this spectralcoin address</source>
        <translation>Pirman ing mensayi ban patune na keka ya ining spectralcoin address</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>Pirman ing &amp;Mensayi</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Ibalik keng dati reng ngan fields keng pamamirmang mensayi</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>I-Clear &amp;Eganagana</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>&amp;Beripikan ing Mensayi</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified spectralcoin address</source>
        <translation>Beripikan ing mensayi ban asiguradu a me pirma ya ini gamit ing mepiling spectralcoin address</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>Beripikan ing &amp;Mensayi</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Ibalik king dati reng ngan fields na ning pamag beripikang mensayi</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ining pane a ini magpakit yang detalyadung description ning transaksion</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletController</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>spectralcoin Core</source>
        <translation>Kapilubluban ning spectralcoin</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Mekapansin lang me-corrupt a block database</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Buri meng buuan pasibayu ing block database ngene?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Kamalian king pamag-initialize king block na ning database</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Kamalian king pamag buklat king block database</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Kamalian: Mababa ne ing espasyu king disk!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Memali ya ing pamakiramdam kareng gang nanung port. Gamita me ini -listen=0 nung buri me ini.</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>&amp;Impormasion</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Maragul yang masiadu ing transaksion</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Kapabaluan</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>E kilalang network ing mepili king -onlynet: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Kulang a pondo</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Lo-load dane ing block index...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Lo-load dane ing wallet...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Ali ya magsilbing i-downgrade ing wallet</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>I-scan deng pasibayu...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Yari ne ing pamag-load</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Mali</translation>
    </message>
</context>
</TS>