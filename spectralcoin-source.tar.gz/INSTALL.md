Building spectralcoin
================

See doc/build-*.md for instructions on building the various
elements of the spectralcoin Core reference implementation of spectralcoin.
